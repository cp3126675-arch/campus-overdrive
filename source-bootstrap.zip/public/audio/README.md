# 配乐贡献

欢迎只贡献音乐，不必同时写播放器代码。先 Fork，在这个目录上传音频并编辑 `tracks.json`，再发 PR。

当前游戏只有程序生成音效；本目录尚无音乐。登记音频不会自动播放，PR 应说明是否包含接入代码，维护者会确认播放时机后接入。

建议格式：MP3 / OGG（播放版），可附 WAV；单文件不超过 10 MiB。适合循环的曲目请检查接缝，避免首尾长静音和削波。请保留原始工程在你自己的存储中，不提交大型 DAW 工程和商业采样库。

`tracks` 中每首音乐填写以下结构（这是说明示例，不代表已经提交了音频）：

```json
{
  "id": "campus-battle",
  "file": "campus-battle.mp3",
  "title": "学堂路冲刺",
  "author": "你的署名",
  "license": "CC-BY-4.0",
  "source": "https://你的作品发布页",
  "usage": "battle",
  "loop": true
}
```

`source` 可填写作品网页，尚未发布的原创作品填 `original`。`usage` 为 `menu`、`battle`、`boss`、`victory`、`defeat` 之一；许可支持 `CC0-1.0`、`CC-BY-4.0`。同一文件只登记一次，文件名使用英文、数字和短横线。PR 请写明授权身份、希望的署名、循环点/时长及试听方式。

检查：`npm run check:contributions`。检查通过表示结构和文件签名符合要求，不代表自动完成版权审核或听感验收。
